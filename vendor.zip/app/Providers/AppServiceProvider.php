<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Tidak ada kode trait atau User di sini
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
